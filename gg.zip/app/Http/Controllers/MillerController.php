<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

//Models
use App\EventsModel;

class MillerController extends Controller
{
    public function index(){

        $events = EventsModel::whereDate('start', '>=', date('Y-m-d'))->orderBy('start', 'DESC')->take(3)->get();
        return view('miller')->with('events', $events);

    }

}
