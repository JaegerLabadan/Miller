<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

//Model;
use App\UsersModel;
use App\EventsModel;
use App\EventBoothsModel;
use App\VendorListByEventsModel;
use App\AttendeesModel;

class VendorController extends Controller
{
    public function index(Request $request){
        $user = $request->session()->get('user');
        $id = $request->session()->get('id');
        $position = $request->session()->get('position');
        $vendor = VendorListByEventsModel::all();
        // $event = EventsModel::where('event_id', $) 

        return view('vendor')->with([
            'user'=> $user,
            'id' => $id,
            'position' => $position,
            'vendor' => $vendor
        ]);
    }

}
