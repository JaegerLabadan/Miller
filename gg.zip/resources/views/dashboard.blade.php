
@extends('layouts.app')

@section('content')
    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }
        
        td, th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        
        tr:nth-child(even) {
            background-color: #dddddd;
        }
    </style>
    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
      <h1 class="h2">Dashboard</h1>
      {{-- <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group mr-2">
          <button class="btn btn-sm btn-outline-secondary">Share</button>
          <button class="btn btn-sm btn-outline-secondary">Export</button>
        </div>
        <button class="btn btn-sm btn-outline-secondary dropdown-toggle">
          <span data-feather="calendar"></span>
          This week
        </button>
      </div> --}}
    </div>

    <!--<canvas class="my-4 w-100" id="myChart" width="900" height="380"></canvas>-->

    <h2>Table of Events</h2>
    <div class="table-responsive">
      <table class="table table-striped table-sm">
        <thead>
          <tr>
            <th>Name of Event</th>
            <th>Location</th>
            <th>Start</th>
            <th>End</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
         @if($position == 'admin') 
          @foreach($events as $e)
            <tr>
              <td>{{ $e->event_name }}</td>
              <td>{{ $e->location }}</td>
              <td>{{ $e->start }}</td>
              <td>{{ $e->end }}</td>
              <td>
                {{-- <form><button style="font-size: 15px; width:89.53px; margin-bottom: 3px;" class="btn btn-primary"><span data-feather="eye"></span> View</button></form>
                <form method="POST" action="{{ url('/delete') }}">
                  @csrf
                  <input type="hidden" name="event_id" value="{{ $e->event_id }}">
                  <button type="submit" style="font-size: 15px;" class="btn btn-danger"><span data-feather="trash"></span> Delete</button>
                </form> --}}
              </td>
            </tr>
          @endforeach
         @else
          @foreach($events as $e)
          <tr>
            <td>{{ $e->event_name }}</td>
            <td>{{ $e->location }}</td>
            <td>{{ $e->start }}</td>
            <td>{{ $e->end }}</td>
            <td>
              {{-- <form><button style="font-size: 15px; width:89.53px; margin-bottom: 3px;" class="btn btn-primary"><span data-feather="eye"></span> View</button></form> --}}
            </td>
          </tr>
        @endforeach
        @endif

        </tbody>
      </table>
    </div>
    </main>
  </div>
</div
@endsection

