@extends('layouts.app')

@section('content')
        <style>
            table {
                font-family: arial, sans-serif;
                border-collapse: collapse;
                width: 100%;
            }
            
            td, th {
                border: 1px solid #dddddd;
                text-align: left;
                padding: 8px;
            }
            
            tr:nth-child(even) {
                background-color: #dddddd;
            }
        </style>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
            <h2>Vendor List By Events</h2>
            <div class="table-responsive">
              <table class="table table-striped table-sm">
                <thead>
                  <tr>
                    <th>Event Name</th>
                    <th>Date</th>
                    <th>Company Name</th>
                    <th>Product Specification</th>
                  </tr>
                </thead>
                <tbody>
                        @foreach($vendor as $v)
                    <tr>
                        <td>{{ $v->event_name }}</td>
                        <td>
                            <?php
                            
                                $start =  $v->start;
                                $end = $v->end;

                                $new_start = date('M d', strtotime($start));
                                $new_end = date('d', strtotime($end));
                                $year = date('Y', strtotime($start));
                                echo "$new_start","-","$new_end",",","$year";
                                
                            ?>
                        </td>
                        <td>{{ $v->company_name }}</td>
                        <td>{{ $v->product_specification }}</td>

                      
                    </tr>
                    @endforeach 
                </tbody>
              </table>
            </div>
            <hr class="hrr">


    </div>
</div>
@endsection
