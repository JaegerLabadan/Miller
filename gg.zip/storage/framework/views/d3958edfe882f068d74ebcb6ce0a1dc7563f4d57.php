<?php $__env->startSection('content'); ?>
        <style>
            table {
                font-family: arial, sans-serif;
                border-collapse: collapse;
                width: 100%;
            }
            
            td, th {
                border: 1px solid #dddddd;
                text-align: left;
                padding: 8px;
            }
            
            tr:nth-child(even) {
                background-color: #dddddd;
            }
        </style>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
            <h2>Vendor List By Events</h2>
            <div class="table-responsive">
              <table class="table table-striped table-sm">
                <thead>
                  <tr>
                    <th>Event Name</th>
                    <th>Date</th>
                    <th>Company Name</th>
                    <th>Product Specification</th>
                  </tr>
                </thead>
                <tbody>
                        <?php $__currentLoopData = $vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($v->event_name); ?></td>
                        <td>
                            <?php
                            
                                $start =  $v->start;
                                $end = $v->end;

                                $new_start = date('M d', strtotime($start));
                                $new_end = date('d', strtotime($end));
                                $year = date('Y', strtotime($start));
                                echo "$new_start","-","$new_end",",","$year";
                                
                            ?>
                        </td>
                        <td><?php echo e($v->company_name); ?></td>
                        <td><?php echo e($v->product_specification); ?></td>

                      
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
              </table>
            </div>
            <hr class="hrr">


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>