<?php $__env->startSection('content'); ?>
<nav class="navbar">
    <div class="container">
            <a class="" style="margin-left: auto; margin-right: auto;" href="#">
            <img style="background-color: none;" src="<?php echo e(asset("images/millerpromotions.logo.png")); ?>" style="    height: 280px;">
            </a>
    </div>
</nav>
            
        <div class="wrapper">
                <div class="container">
                <form method="POST" action="<?php echo e(url('create_account')); ?>">
                        <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col">
                        <input type="text" class="form-control rad" name="username" placeholder="Username">
                        </div>
                        <div class="col">
                        <input type="password" class="form-control rad" name="password" placeholder="Password">
                        </div>
                    </div>

                    <div class="row" style="    padding-top: 25px;">
                        <div class="col">
                            <input type="text" class="form-control rad" name="firstname" placeholder="First name">
                        </div>
                        <div class="col">
                            <input type="text" class="form-control rad" name="lastname" placeholder="Last name">
                        </div>
                    </div>
                
                    <div class="row" style="    padding-top: 25px;">
                        <div class="col">
                        <input type="text" class="form-control rad" name="companyname" placeholder="Company/Business Name">
                        </div>
                    </div>
        
                    <div class="row" style="    padding-top: 25px;">
                        <div class="col">
                        <select name="title">
                            <option value="" disabled selected>Job Title</option>  
                            <option value="volvo">Owner</option>
                            <option value="saab">Representative</option>
                            <option value="opel">Reseller</option>
                            <option value="audi">Employee</option>
                        </select>
                        </div>
                        <div class="col">
                        <select name="companyindustry">
                            <option value="" disabled selected>Industry</option>  
                            <option value="Industrial">Industrial</option>
                            <option value="Real Estate">Real Estate</option>
                            <option value="Cosmetics">Cosmetics</option>
                            <option value="Handmade">Handmade Products</option>
                            <option value="Hobby">Hobby</option>
                            <option value="Entertainment">Entertainment</option>
                            <option value="Automotive">Automotive</option>
                        </select>
                        </div>
                    </div>
        
                    <div class="row" style="padding-top: 25px;">
                        <div class="col">
                            <select name="productspect">
                                <option value="" disabled selected>Products/Services Specialty</option>  
                                <option value="Commercial Products">Commercial Products</option>
                                <option value="Commercial Services">Commercial Services</option>
                                <option value="Music/Band">Music/Band</option>
                                <option value="Handmade products">Handmade products</option>
                                <option value="Import">Import</option>
                                <option value="Direct Re-selling">Direct Re-selling</option>
                            </select>
                        </div>
                    </div>
        
                    <div class="row" style="    padding-top: 25px;">
                        <div class="col">
                            <input type="text" name="addressone" class="form-control rad" placeholder="Street Address">
                        </div>
                    </div>
        
                    <div class="row" style="    padding-top: 25px;">
                        <div class="col">
                        <input type="text" name="city" class="form-control rad" placeholder="City">
                        </div>
                        <div class="col">
                        <input type="text" name="zip" class="form-control rad" placeholder="ZIP">
                        </div>
                    </div>
        
                    <div class="row" style="    padding-top: 25px;">
                        <div class="col">
                        <input type="text" name="phone" class="form-control rad" placeholder="Phone">
                        </div>
                        <div class="col">
                        <input type="text" name="fax" class="form-control rad" placeholder="FAX">
                        </div>
                    </div>
        
                    <div class="row" style="    padding-top: 25px;">
                        <div class="col">
                            <input type="email" class="form-control rad" name="" placeholder="Email">
                        </div>
                    </div>
        
                    <div class="row" style="    padding-top: 25px;">
                        <div class="col">
                            <button class="btn" type="submit">
                                SAVE
                            </button>
                        </div>
                    </div>
        
                    </form>
                </div>
            </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>