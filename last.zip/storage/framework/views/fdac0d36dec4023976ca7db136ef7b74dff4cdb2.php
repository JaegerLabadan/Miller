<?php $__env->startSection('content'); ?>
<div class="courses-area mg-b-15">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10" style="float: right;">
                <div class="white-box">
                      <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                        <th>Name of Event</th>
                        <th>Location</th>
                        <th>Start</th>
                        <th>End</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if($position == 'admin'): ?> 
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($e->event_name); ?></td>
                            <td><?php echo e($e->location); ?></td>
                            <td><?php echo e($e->start); ?></td>
                            <td><?php echo e($e->end); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($e->event_name); ?></td>
                        <td><?php echo e($e->location); ?></td>
                        <td><?php echo e($e->start); ?></td>
                        <td><?php echo e($e->end); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>