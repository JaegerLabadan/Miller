<?php $__env->startSection('content'); ?>
<script>
     jQuery(document).ready(function (){
        $('#event').change(function(){
            var event = $(this).val();
            $.ajax({
                url: "<?php echo e(url('getBooths')); ?>",
                method: "GET",
                data : {
                    id: event
                },
                success: function(result){
                    var counter = 0;
                    $.each(result, function(){
                        $('#slots').append('<li><input type="checkbox" name="booth[]"data-day="'+result[counter]["day"]+'" data-event="'+result[counter]["event_id"]+'" data-price="'+result[counter]["booth_price"]+'" class="form-check-input booths" value="'+result[counter]["booth_space"]+'" data-id="'+result[counter]["eb_id"]+'"> '+result[counter]["booth_space"]+' Space <span class="mon">'+result[counter]["booth_specification"]+' - <strong>'+result[counter]["day"]+' '+result[counter]["booth_price"]+'</strong> </span></li>');
                        counter += 1;
                    });
                }
            });
        });
     });
</script>
        <!-- Modal -->
          <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">
            
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Add Event for Vendor</h4>
                </div>
                <form method="POST" action="<?php echo e(url('manual_add')); ?>">
                <div class="modal-body">
                    <div class="col-sm-12">
                        <div class="row">
                            <div class="col-sm-6">
                                <select class="form-control rady"  name="event_id" id="event">
                                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($e->event_id); ?>"><?php echo e($e->event_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <input type="text" class="form-control rady" name="company_name" placeholder="Company/Vendor Name">
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12" style="padding-top: 10px;">
                            
                        <select class="form-control rady" name="product_specification" id="">
                            <option value="" disabled selected>Products/Services Specialty</option>  
                            <option value="Commercial Products">Commercial Products</option>
                            <option value="Commercial Services">Commercial Services</option>
                            <option value="Music/Band">Music/Band</option>
                            <option value="Handmade products">Handmade products</option>
                            <option value="Import">Import</option>
                            <option value="Direct Re-selling">Direct Re-selling</option>
                        </select>
                    </div>

                    <div class="col-sm-12" style="padding-top: 10px;">
                        <label>Slots</label>

                        <ul class="yul" id="slots">
                            
                        </ul>
                    </div>

                    <div class="col-sm-12" style="padding-top: 10px;">
                        <div class="col">
                            <button type="submit" class="form-control radishes rady" id="manual_add"><i class="fa fa-check-square"></i> Save</button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer" >
                  <button type="button" style="margin-top: 10px;" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
                </form>
              </div>
              
            </div>
          </div>
        
        <div class="courses-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="white-box">
                            <h3 class="box-title">Vendor List by Events</h3>

                            <div class="col-sm-12" style="padding-right: 0; padding-left: 0; padding-bottom: 25px; padding-top: 25px;">
                                <!-- <button class="form-control rady radishes"><i class="fa fa-check-square"></i> Create Event</button> -->
                                <button type="button" style="width: 40%;" class="btn btn-lg form-control rady radishes" data-toggle="modal" data-target="#myModal"><i class="fa fa-plus-square"></i> Add Event</button>
                            </div>

                            <div class="tabi">                      
                              <table class="table table-bordered table-hover">
                                <thead>
                                  <tr>
                                    <th>Event Name</th>
                                    <th>Company Name</th>
                                    <th>Product Specification</th>
                                    <th>Start</th>
                                    <th>End</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <?php $__currentLoopData = $vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                    <td><?php echo e($v->event_name); ?></td>
                                    <td><?php echo e($v->company_name); ?></td>
                                    <td><?php echo e($v->product_specification); ?></td>
                                    <td><?php echo e($v->start); ?></td>
                                    <td><?php echo e($v->end); ?></td>
                                  </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                              </table>
                            </div>
                        </div>  
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>