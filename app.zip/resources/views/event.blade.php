@extends('layouts.app')
@section('content')
    <h1>View Page</h1>
@endsection