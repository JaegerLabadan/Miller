<?php $__env->startSection('content'); ?>
    <script>
        $(document).ready(function(){
            //Added Fields in Space
            $("#add_spaces").click(function(){
                $("#add_space").append("<input type='text' class='form-control' name='space[]' /><button type='button' class='btn btn-danger' id='remove_space_all'>X</button>");
                $('#add_number_of_space').append('<input type="number" class="form-control" name="number_of_space[]" />');
                $('#add_space_price').append('<input type="number" class="form-control" name="space_price[]" />');
            });
            $("#remove_space_all").click(function(){
                alert('clicked!');
                $("#add_space").empty();
                $('#add_number_of_space').empty();
                $('#add_space_price').empty();
            });
    
            //Added Fields in Items
            $("#add_items").click(function(){
                $('#add_item').append('<input type="text" class="form-control" name="item[]" />');
                $('#add_specifications').append('<input type="text" class="form-control" name="specifications[]" />');
                $('#add_item_price').append('<input type="number" class="form-control" name="rental_price[]" />');
                $('#add_stock').append('<input type="number" class="form-control" name="number_of_stock[]" />');
            });
    
            //Save Event
            $('#save_event').click(function(){
                alert("clicked!");
                var data = new FormData(document.getElementById('event_form'));
                $.ajax({
                    url: '<?php echo e(url('save_event_info')); ?>',
                    type: 'POST',
                    data: data,
                    dataType: 'json',
                    processData: false,
                    contentType: false,
                    success:function(result){
                        console.log(result);
                    }
                });
            });
        });
    </script>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Dashboard</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                
                </div>
            </div>
            <h2>Create an Event</h2>
            <form method="POST" action="<?php echo e(url('event_store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <label for="" class="col-sm-2 col-form-label">Event Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="event_name" placeholder="Event Name">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="" class="col-sm-2 col-form-label">Location</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="location" placeholder="Location">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="" class="col-sm-2 col-form-label">Start of Event</label>
                    <div class="col-sm-10">
                        <input type="date" class="form-control" name="start_of_event">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="" class="col-sm-2 col-form-label">End of Event</label>
                    <div class="col-sm-10">
                        <input type="date" class="form-control" name="end_of_event">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="" class="col-sm-2 col-form-label">Event Banner</label>
                    <div class="col-sm-10">
                        <input type="file" class="form-control" name="event_banner">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary"><span data-feather="check-square"></span> Create Event</button>
                    </div>
                </div>
            </form>
        </main>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>