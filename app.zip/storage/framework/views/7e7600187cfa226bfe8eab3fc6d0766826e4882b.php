<?php $__env->startSection('content'); ?>

        <script>
           var totalBooth = 0;
           var totalAmount = 0;
           var boothsSelected = [];
           var eventsSelected = [];
           var receiptBooths = [];
            jQuery(document).ready(function (){
               var booths_purchased = $('#booths_purchased').clone();
               var events_selected = $('#events_selected').clone();
               var receipt_booths = $('#receipt_booths').clone();
               
               $("input[name='events[]']").change(function(){
                  // alert('value changed!');
                  var eve = 0;
                  // var name = "";
                  var name = [];
                  $("input[name='events[]']").each(function()
                     {	
                        if($(this).prop('checked')){
                           // eve.push($(this).attr('data-id'));
                           eve = $(this).attr('data-id');
                           name.push($(this).attr('data-name'));
                        }
                        
                     }
                  );
                  // var eve = $(this).prop('checked').val();
                  // var name = $(this).val();
                  console.log(name);
                  console.log(eve);
                  $.ajax({
                     url: "<?php echo e(url('getBooths')); ?>",
                     method: "GET",
                     data: {
                        id: eve
                     },
                     success:function(result){
                        $('#events_selected').replaceWith(events_selected.clone());
                        var counter = 0;
                        var holders = [];
                        console.log(result.length);
                        $.each(result, function(){
                           console.log(result[counter]['event_id']);
                           $('[data-booth="'+result[counter]["event_id"]+'"]').append('<li><input type="checkbox" name="booth[]"data-day="'+result[counter]["day"]+'" data-event="'+result[counter]["event_id"]+'" data-price="'+result[counter]["booth_price"]+'" class="form-check-input booths" value="'+result[counter]["booth_space"]+'" data-id="'+result[counter]["eb_id"]+'"> '+result[counter]["booth_space"]+' Space <span class="mon">'+result[counter]["booth_specification"]+' - <strong>'+result[counter]["day"]+' '+result[counter]["booth_price"]+'</strong> </span></li>');
                           counter += 1;
                        });
                        // for(var counter = 0; counter < result.length; counter++){
                        //    console.log(result[counter]['event_id']);
                        //    $('[data-booth="'+result[counter]["event_id"]+'"]').append('<input type="checkbox" name="booth[]" data-day="'+result[counter]["day"]+'" data-price="'+result[counter]["booth_price"]+'" class="form-check-input booths" value="'+result[counter]["booth_space"]+'" id=""><label for="" class="form-check-label">'+result[counter]["booth_space"]+'  '+result[counter]["booth_specification"]+' '+result[counter]["day"]+' - <strong>'+result[counter]["booth_price"]+'$</strong></label><br>');
                        //    counter += 1;
                        // }
                        for(var counter = 0; counter < name.length; counter++){
                           $('#events_selected').append('<h6>'+name[counter]+'</h6>');
                        }
                        
                     }
                  });
               });
               $(document).on('change', '.booths', function(){
                  $('#booths_purchased').replaceWith(booths_purchased.clone());

                  // alert('booth clicked!');
                  var boothPrices = [];
                  var boothNames = [];
                  var boothDays = [];
                  // var boothName = [];
                  var boothTotal = 0;
                  jQuery("input[name='booth[]']").each(function()
                     {	
                        if($(this).prop('checked')){
                           boothPrices.push($(this).attr('data-price'));
                           boothDays.push($(this).attr('data-day'));
                           boothNames.push($(this).val());
                              // alert($(this).attr('data-price'));
                        }
                        
                     }
                  );
                  for(var counter = 0; counter < boothPrices.length; counter++){
                     boothTotal += boothPrices[counter] << 0;
                    //  $("#booths_purchased").append('<h5>'+boothNames[counter]+' SPACE '+boothPrices[counter]+'$ DAY '+boothDays[counter]+'</h5>');
                      $('#booths_purchased').append('<div class="row"><div class="col-sm-9 mons"> '+boothNames[counter]+' SPACE '+boothDays[counter]+'</div><div class="col-sm-3 mons">$'+boothPrices[counter]+'</div></div>');
                  }
                  console.log(boothPrices);
                  console.log(boothNames);
                  console.log(boothDays);

                  totalBooth = boothTotal;
                  $('input[name="totalAmountDue"]').val(totalAmount = totalBooth);
 
               });
               $('#save_attendee').click(function(){
                  $("input[name='events[]']").each(function(){
                     if($(this).prop('checked')){
                        var new_array = {
                          event_id: $(this).attr('data-id')
                        }
                        eventsSelected.push(new_array);
                     }	
                     
                  });
                  $("input[name='booth[]']").each(function(){
                     if($(this).prop('checked')){
                        var new_array = {
                          event_id: $(this).attr('data-event'),
                          booth_id: $(this).attr('data-id'),
                          booth_name: $(this).val(),
                          booth_price: $(this).attr('data-price'),
                          day: $(this).attr('data-day')
                        }
                        boothsSelected.push(new_array);
                     }
                     
                  });
                  $.ajax({
                    url: "<?php echo e(url('join_events')); ?>",
                    method: "post",
                    data: {
                      events: eventsSelected,
                      booths: boothsSelected,
                      totalAmountDue: $('input[name="totalAmountDue"]').val()
                    },
                    success: function(result){
                      console.log(result);
                    }
                  });	
               });
            });
        </script>
<div class="courses-area mg-b-15">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="white-box">
                  <?php if($nature->nature == 'Vendor'): ?>
                        <div class="container">
                            <h1 class="heads">EVENT APPLICATION FORM</h1>
                
                            <div class="row" style="padding-top: 20px;">
                              <div class="col">
                                <h5>Choose the Event/s (Click all the applies)</h5>
                              </div>
                            </div>
                
                            <div class="row" style="width: 80%; margin-left: auto; margin-right: auto;">
                              <div class="col">
                                
                                <form action=""></form>
                                <?php echo csrf_field(); ?>
                                <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <p>
                                    <h5 class="mon"><?php echo e($e); ?></h5>
                                      <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($ev->location == $e): ?>
                                          <input class="" type="checkbox" data-name="<?php echo e($ev->event_name); ?> <?php echo e($ev->category_of_event); ?>" value="<?php echo e($ev->event_id); ?>" data-id="<?php echo e($ev->event_id); ?>" name="events[]" id="event_holder">
                                          <?php
                                                $start = $ev->start;
                                                $end = $ev->end;

                                                $new_start = date('M d', strtotime($start));
                                                $new_end = date('d', strtotime($end));
                                                $year = date('Y', strtotime($end));
                                                echo "$new_start", "-", "$new_end",",","$year";
                                          ?> <span class="mon"> <?php echo e($ev->event_name); ?> <?php echo e($ev->category_of_event); ?></span> <br>
                                          <ul class="yuel" id="booth_holder" data-booth="<?php echo e($ev->event_id); ?>">
                                          </ul>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </p>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
          
                                  <p>
                                    <h5 class="mon">Your Set-up Schedule</h5>
                                    <input class="rad" type="text" name="setup">
                                  </p>
                
                                  <p>
                                    <h5 class="mon">Table Cloth Rental</h5>
                                    <input class="rad" type="text" name="cloth">
                                  </p>
                
                                  <p class="par" style="font-size: 13px; fonr-weight: 100!important;">
                                    <span class="mon" style="padding-bottom: 5px; font-size: 18px;">Please read and agree to complete your application process.</span><br>
                                    Exhibitor indemnifies and hold harmless merchant and leasing association, mall owners, 
                                    Miller Promotions, any property management group holding the event, Susan Miller,
                                    show managers and all merchants leasing or owning space in said mall, or show, 
                                    their agents and employees from and against any and all liability, claims, thefts, 
                                    demands, expenses, fees and penalties, suits, proceedings, actions, and causes of 
                                    action of any and every kind and nature arising or growing out of or in any way connected 
                                    with Exhibitor's use of occupancy of mall or any Exhibitor's activities in said mall (show)
                                    . Exhibitor acknowledges and agrees to abide by all guidelines, rules, and regulations set 
                                    forth by Miller Promotions, which are found on www.GiftandCraftExpo.com or available by mall, 
                                    as well as set forth by mall owners, for all Miller Promotions shows you participate in. 
                                    Miller Promotions and the mall management reserves the right to refuse space to or remove 
                                    any exhibitor who does not comply with, accept, or cooperate with guidelines as stated in 
                                    Miller Promotions, rules and regulations even if exhibitor has already been accepted into shows.
                                      Miller Promotions and mall management reserves the right to ask an exhibitor to remove and/or change
                                      any item or signage within booth space relative to the levels of professional standards 
                                      set by the mall or Miller Promotions or if a product is in direct competition with another 
                                      in-line store or cart/kiosk at the time of the show, anytime during the show, even if already
                                        accepted in advance. <br><br>
                
                                        I also understand that there are no refunds: Registrations is a
                                        commitment to the show. <br>NO REFUNDS! NO EXCEPTIONS! Once my application with payment has 
                                        been received, no refunds will be honored. This also applies to no shows, late arrivals to 
                                        the show, illness, family circumstances, and any type of request for refund. Spaces cannot
                                        be re-rented without the approval of the show promoter.
                                  </p>
                
                                  <p>
                                    <input type="checkbox" name="" value=""><span> I agree to the terms outlined in this online application.</span> <br>
                                    <input type="checkbox" name="" value="" ><span> I understand that the show promoter, the mall management, and all of its agents are not responsible for lost, stolen, or damaged, merchandise of mine.</span> <br>
                                    <input type="checkbox" name="" value=""><span> I understand that I am responsible for my own insurance and I should provide proof of insurance. Failure to secure insurance will make me liable for any claims or suits held against me by the customer or people attending the event.</span>
                                  </p>
                
                                  <hr class="hrt">
                
                                  <p>
                                    <h5 class="mon">SUMMARY</h5><br>
                                    <div class="hed" style="text-align: center;" id="events_selected">

                                    </div>
                                    <div class="col-sm-12" style="text-align: right;" id="booths_purchased">

                                    </div>
                                    <div class="col-sm-12" style="text-align: right;">
                                      <div class="row">
                                        <div class="col-sm-9 mons">
                                          HAVE A PROMO CODE?
                                        </div>
                                        <div class="col-sm-3 mons">
                                          <input class="rads" type="" name="" placeholder="enter it here">
                                        </div>
                                      </div>
                                    </div>
                                    <div class="col-sm-12" style="text-align: right;">
                                      <div class="row">
                                        <div class="col-sm-9 mons">
                                          DISCOUNT
                                        </div>
                                        <div class="col-sm-3 mons">
                                          $180
                                        </div>
                                      </div>
                                    </div>
                                    <div class="col-sm-12" style="text-align: right;">
                                      <div class="row">
                                        <div class="col-sm-9 mons">
                                          TAX
                                        </div>
                                        <div class="col-sm-3 mons">
                                          $180
                                        </div>
                                      </div>
                                    </div>
                                    <hr class="hrt">
                
                                    <div class="col-sm-12" style="text-align: right;">
                                      <div class="row">
                                        <div class="col-sm-9">
                                          <span class="mons daks">
                                            TOTAL
                                          </span>
                                        </div>
                                        <div class="col-sm-3">
                                          <span class="mons">
                                            <input class="radi" type="" name="totalAmountDue" placeholder="$ 180.50"> 
                                          </span> 
                                        </div>
                                      </div>
                                    </div>
                                  </p>
                                  <button class="btn rars">
                                      PAY NOW
                                    </button>
                                </form>
                              </div>
                            </div>
                        </div>
                    </div>
                  <?php endif; ?>

            </div>
        </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>