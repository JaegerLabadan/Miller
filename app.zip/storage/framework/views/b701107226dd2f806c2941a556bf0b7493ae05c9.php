<?php $__env->startSection('content'); ?>
 <!-- ----------------------------Section 1------------------------------------ -->

 <div class=" wrapper" style="    padding-top: 185px; padding-bottom: 80px;">
        <div class="container">

            <h1 class="agay">TESTIMONIALS</h1>

            <div class="row" style="    text-align: center; padding-bottom: 50px;">
                <div class="col">
                    <span style="font-weight: 800;">
                        We always love to hear from you about the event!
                    </span> 
                </div>
            </div>

            <h3 class="agays">
                "1st Annual Luv That Black N Gold Gift And Craft Expo  - Shoppes At Northway Sept. 2012"
            </h3>

            <div class="container caros">
                <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user1.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
            </div>

            <h3 class="agays">
                "CHRISTMAS GIFT AND CRAFT EXPO 2010"
            </h3>

            <div class="container caros">
                <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user1.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
            </div>

            <h3 class="agays">
                "GIFTS AND CRAFTS FOR VALENTINE EXPO 2010"
            </h3>

            <div class="container caros">
                <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user1.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
            </div>

            <h3 class="agays">
                "WINTER MELTDOWN AT WESTMORELAND MALL"
            </h3>

            <div class="container caros">
                <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user1.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
            </div>

            <h3 class="agays">
                "GIFTS AND CRAFTS FOR VALENTINE EXPO 2014"
            </h3>

            <div class="container caros">
                <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user1.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
            </div>

            <h3 class="agays">
                "GIFTS AND CRAFTS FOR VALENTINE EXPO 2013"
            </h3>

            <div class="container caros">
                <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user1.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
            </div>

            <h3 class="agays">
                "GIFTS AND CRAFTS FOR VALENTINE EXPO 2013"
            </h3>

            <div class="container caros">
                <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user1.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
            </div>

            <h3 class="agays">
                "CHRISTMAS GIFT AND CRAFT EXPO 2011"
            </h3>

            <div class="container caros">
                <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user1.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
            </div>

            <h3 class="agays">
                "PAMPERFEST 2010"
            </h3>

            <div class="container caros">
                <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user1.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
            </div>

            <h3 class="agays">
                "PAMPERFEST 2010"
            </h3>

            <div class="container caros">
                <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user1.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
            </div>

            <h3 class="agays">
                "ALWAYS WORTH IT"
            </h3>

            <div class="container caros">
                <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user1.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
            </div>

            <h3 class="agays">
                "MORE THAN PROFESSIONAL"
            </h3>

            <div class="container caros">
                <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user1.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                    <div class="carousel-item">
                        <img src="images/user.png" alt="Avatar" style="width:90px"><br>
                        <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
                        <p>John Doe saved us from a web disaster.</p>
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
            </div>
            
        </div>
    </div>

 <!-- ---------------------------------------------------------------- -->


 <section class="sec3">
    <div class="container caro">
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" style="    height: 245px;">
      <ol class="carousel-indicators" style="bottom: -60px;">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      </ol>
      
      <div class="carousel-inner" style="    height: 270px;">
        <?php if(count($vendors) == 1): ?>
            <?php for($i = 0; $i < count($vendors); $i++): ?>
            <div class="carousel-item active">
                    <div class="row">
                        <div class="col-sm-6" style="padding: 0;">
                            <img class="d-block w-100" src="<?php echo e(asset('images/stacy.PNG')); ?>" alt="First slide">
                        </div>
                        <div class="col-sm-6" style="background: #00D0EA; padding-top: 15px;">
                            <h1 style="text-align: center; font-family: 'Montserrat', sans-serif!important; font-weight: 800;">
                                CATCH <span style="text-transform: uppercase"><?php echo e($vendors[0]->vendor_name); ?></span> ON:
                            </h1>
                            <h5 style="color: #fff; padding-left:45px;">
                                <?php
                                    $start = $vendors[0]->start;
                                    $end = $vendors[0]->end;

                                    $new_start = date('F d', strtotime($start));
                                    $new_end = date('d', strtotime($end));
                                    echo "$new_start", " ", "&", " ", "$new_end";
                                ?><br>
                                <?php echo e($vendors[0]->event_name); ?><br>
                            </h5>
                        </div>
                    </div>
                </div>
            <?php endfor; ?>
        <?php else: ?>
            <div class="carousel-item active">
                    <div class="col-sm-12">
                        <div class="row">
                            <div class="col-sm-6" style="padding: 0;">
                                <img class="d-block w-100" src="<?php echo e(asset("images/stacy.PNG")); ?>" alt="First slide">
                            </div>
                            <div class="col-sm-6" style="background: #00D0EA; padding-top: 15px;">
                                <h1 style="text-align: center; font-family: 'Montserrat', sans-serif!important; font-weight: 800;">
                                    CATCH <span style="text-transform: uppercase"><?php echo e($vendors[0]->vendor_name); ?></span> ON:
                                </h1>
                                <h5 style="color: #fff; padding-left:45px;">
                                    <?php
                                        $start = $vendors[0]->start;
                                        $end = $vendors[0]->end;

                                        $new_start = date('F d', strtotime($start));
                                        $new_end = date('d', strtotime($end));
                                        echo "$new_start", " ", "&", " ", "$new_end";
                                    ?><br>
                                    <?php echo e($vendors[0]->event_name); ?><br>
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
            <?php for($z = 0; $z < 16; $z++): ?> 
            <div class="carousel-item">
                    <div class="col-sm-12">
                        <div class="row">
                            <div class="col-sm-6" style="padding: 0;">
                                <img class="d-block w-100" src="<?php echo e(asset('images/stacy.PNG')); ?>" alt="First slide">
                            </div>
                            <div class="col-sm-6" style="background: #00D0EA; padding-top: 15px;">
                                <h1 style="text-align: center; font-family: 'Montserrat', sans-serif!important; font-weight: 800;">
                                    CATCH <span style="text-transform: uppercase"><?php echo e($vendors[$z]->vendor_name); ?></span> ON:
                                </h1>
                                <h5 style="color: #fff; padding-left:45px;">
                                    <?php
                                        $start = $vendors[$z]->start;
                                        $end = $vendors[$z]->end;

                                        $new_start = date('F d', strtotime($start));
                                        $new_end = date('d', strtotime($end));
                                        echo "$new_start", " ", "&", " ", "$new_end";
                                    ?><br>
                                    <?php echo e($vendors[$z]->event_name); ?><br>
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endfor; ?>
        <?php endif; ?>
        
    
    </div>
      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
    </div>

    <div class="container days">
        <div id="carouselExampleSlidesOnly" class="carousel slide" data-interval="10000" data-ride="carousel">
          <div class="carousel-inner">
            <?php if(count($events) == 1): ?>
                <?php for($i = 0; $i < count($events)-2; $i++): ?>           
                <div class="carousel-item active">
                        <div class="col-sm-12">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="tri">
                                            <?php
                                            
                                            $current = date('Y-m-d');
                                            $start = $events[$i]->start;
                                            $date1 = new Datetime($current);
                                            $date2 = new Datetime($start);
                                            $diff = $date2->diff($date1)->format('%a');
                                            $days = intval($diff);
                                            if($days == 1){ 
                                                echo "<h1 class='hi'>".$days."</h1><span class='sp'>DAY TO GO<br></span>";
                                            }
                                            elseif($days == 0) {
                                                echo "<h1 class='hi'>".$days."</h1><span class='sp'>NOW<br></span>";   
                                            }
                                            else{
                                                echo "<h1 class='hi'>".$days."</h1><span class='sp'>DAYS TO GO<br></span>";
                                            }
                                            
                                            ?>
                                    </div>
                                </div>
                                <div class="col-sm-8">
                                    <h1 class="bul">
                                        <?php
                                        $start = $events[$i]->start;
                                        $end = $events[$i]->end;
        
                                        $new_start = date('F d', strtotime($start));
                                        $new_end = date('d', strtotime($end));
                                        $year = date('Y', strtotime($end));
                                        echo "$new_start", " ", "-", " ", "$new_end", " ", "$year";
                                    ?>
                                    </h1>
                                    <h1 class="bul" style="line-height: .2;">
                                        <?php echo e($events[$i]->event_name); ?>

                                    </h1><br>
                                    <span style="color: #fff; font-weight: 800;">
                                        <?php echo e($events[$i]->location); ?><br>
                                        Pa. (Benfits the Pittsburgh Food Bank)
                                    </span>
                                    <p style="margin-top: 1rem;">
                                        <button class="btn" style="margin-right: 80px; border-radius: 20px; background: #02F5FD; color: #fff;"><a style="color: #ffff; text-decoration: none;" href="#">ALL EVENT LIST</a></button>
                                        <button class="btn" style="border-radius: 20px; background: #00CDDB; color: #fff;"><a style="color: #ffff; text-decoration: none;" href="<?php echo e(url('form')); ?>">JOIN THIS EVENT</a></button>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endfor; ?>
            <?php else: ?>
                <?php for($i = 0; $i < count($events)-2; $i++): ?>           
                <div class="carousel-item active">
                        <div class="col-sm-12">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="tri">
                                        <?php
                                            
                                            $current = date('Y-m-d');
                                            $start = $events[$i]->start;
                                            $date1 = new Datetime($current);
                                            $date2 = new Datetime($start);
                                            $diff = $date2->diff($date1)->format('%a');
                                            $days = intval($diff);
                                            if($days == 1){ 
                                                echo "<h1 class='hi'>".$days."</h1><span class='sp'>DAY TO GO<br></span>";
                                            }
                                            elseif($days == 0) {
                                                echo "<h1 class='hi'>".$days."</h1><span class='sp'>NOW<br></span>";   
                                            }
                                            else{
                                                echo "<h1 class='hi'>".$days."</h1><span class='sp'>DAYS TO GO<br></span>";
                                            }
                                            
                                            ?>
                                </div>
                            </div>
                            <div class="col-sm-8">
                                <h1 class="bul">
                                    <?php
                                    $start = $events[$i]->start;
                                    $end = $events[$i]->end;
        
                                    $new_start = date('F d', strtotime($start));
                                    $new_end = date('d', strtotime($end));
                                    $year = date('Y', strtotime($end));
                                    echo "$new_start", " ", "-", " ", "$new_end", " ", "$year";
                                ?>
                                </h1>
                                <h1 class="bul" style="line-height: .2;">
                                    <?php echo e($events[$i]->event_name); ?>

                                </h1><br>
                                <span style="color: #fff; font-weight: 800;">
                                    <?php echo e($events[$i]->location); ?><br>
                                    Pa. (Benfits the Pittsburgh Food Bank)
                                </span>
                                <p style="margin-top: 1rem;">
                                    <button class="btn" style="margin-right: 80px; border-radius: 20px; background: #02F5FD; color: #fff;"><a style="color: #ffff; text-decoration: none;" href="#">ALL EVENT LIST</a></button>
                                    <button class="btn" style="border-radius: 20px; background: #00CDDB; color: #fff;"><a style="color: #ffff; text-decoration: none;" href="<?php echo e(url('form')); ?>">JOIN THIS EVENT</a></button>
                                </p>
                            </div>
                        </div>
                        </div>
                    </div>
				<?php endfor; ?>
				<?php for($i = 1; $i < count($events); $i++): ?>
				<div class="carousel-item">
					<div class="col-sm-12">
					<div class="row">
						<div class="col-sm-4">
							<div class="tri">
									<?php
										
										$current = date('Y-m-d');
										$start = $events[$i]->start;
										$date1 = new Datetime($current);
										$date2 = new Datetime($start);
										$diff = $date2->diff($date1)->format('%a');
										$days = intval($diff);
										
										if($days == 1){ 
											echo "<h1 class='hi'>".$days."</h1><span class='sp'>DAY TO GO<br></span>";
										}
										elseif($days == 0) {
											echo "<h1 class='hi'>".$days."</h1><span class='sp'>NOW<br></span>";   
										}
										else{
											echo "<h1 class='hi'>".$days."</h1><span class='sp'>DAYS TO GO<br></span>";
										}
										
										?>
							</div>
						</div>
						<div class="col-sm-8">
							<h1 class="bul">
								<?php
								$start = $events[$i]->start;
								$end = $events[$i]->end;

								$new_start = date('F d', strtotime($start));
								$new_end = date('d', strtotime($end));
								$year = date('Y', strtotime($end));
								echo "$new_start", " ", "-", " ", "$new_end", " ", "$year";
							?>
							</h1>
							<h1 class="bul" style="line-height: .2;">
								<?php echo e($events[$i]->event_name); ?>

							</h1><br>
							<span style="color: #fff; font-weight: 800;">
									<?php echo e($events[$i]->location); ?><br>
								Pa. (Benfits the Pittsburgh Food Bank)
							</span>
							<p style="margin-top: 1rem;">
								<button class="btn" style="margin-right: 80px; border-radius: 20px; background: #02F5FD; color: #fff;"><a style="color: #ffff; text-decoration: none;" href="#">ALL EVENT LIST</a></button>
								<button class="btn" style="border-radius: 20px; background: #00CDDB; color: #fff;"><a style="color: #ffff; text-decoration: none;" href="<?php echo e(url('form')); ?>">JOIN THIS EVENT</a></button>
							</p>
						</div>
					</div>
					</div>
				</div>
				<?php endfor; ?>
            <?php endif; ?>
            
            
          </div>
        </div>
    </div>
</section>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>