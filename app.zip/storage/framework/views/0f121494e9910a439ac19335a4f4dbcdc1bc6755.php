<?php $__env->startSection('content'); ?>
        <style>
            table {
                font-family: arial, sans-serif;
                border-collapse: collapse;
                width: 100%;
            }
            
            td, th {
                border: 1px solid #dddddd;
                text-align: left;
                padding: 8px;
            }
            
            tr:nth-child(even) {
                background-color: #dddddd;
            }
        </style>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
            <h2>Vendor List By Events</h2>
            <div class="table-responsive">
              <table class="table table-striped table-sm">
                <thead>
                  <tr>
                    <th>Company Name</th>
                    <th>Product Specification</th>
                    <th>Event Name</th>
                    <th>Start</th>
                    <th>End</th>
                  </tr>
                </thead>
                <tbody>
                        <?php $__currentLoopData = $vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      
                        <td><?php echo e($v->company_name); ?></td>
                        <td><?php echo e($v->product_specification); ?></td>
                        <td><?php echo e($v->event_name); ?></td>
                        <td>
                            <?php
                            
                                $start =  $v->start;

                                $new_start = date('M d', strtotime($start));
                                $year = date('Y', strtotime($start));
                                echo "$new_start",",","$year";
                                
                            ?>
                        </td>
                        <td>
                            <?php
                            
                                $end = $v->end;

                                $new_end = date('M d', strtotime($end));
                                $year = date('Y', strtotime($start));
                                echo "$new_end",",","$year"
                                
                            ?>
                        </td>
                      
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
              </table>
            </div>
            <hr class="hrr">

            <h2>Vendor List Alltime</h2>
            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th>Company Name</th>
                            <th>Product Specification</th>
                            <th>Number of Joined Events</th>
                            <th>Since</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                          <td>Dummy Company</td>
                          <td>Handcrafted</td>
                          <td>99999</td>
                          <td>Nov. 28, 2018</td>
                        </tr>
                    </tbody>
                </table>
            </div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>